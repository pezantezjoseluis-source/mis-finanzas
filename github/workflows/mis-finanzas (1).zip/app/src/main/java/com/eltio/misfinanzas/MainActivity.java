package com.eltio.misfinanzas;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Mis Finanzas — Creada por el Tío.
 * La app es una página web guardada dentro de la APK. Se sirve desde una
 * dirección https propia para que el almacenamiento del teléfono funcione bien.
 */
public class MainActivity extends Activity {

    private static final String HOST = "misfinanzas.app";
    private static final int PEDIR_ARCHIVO = 11;

    private WebView web;
    private ValueCallback<Uri[]> archivoCallback;
    private Uri fotoUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(true);

        web.addJavascriptInterface(new Puente(), "Android");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (!HOST.equals(u.getHost())) return null;
                String ruta = u.getPath();
                if (ruta == null || ruta.isEmpty() || ruta.equals("/")) ruta = "/index.html";
                try {
                    InputStream in = getAssets().open(ruta.substring(1));
                    return new WebResourceResponse(tipo(ruta), "utf-8", in);
                } catch (IOException e) {
                    return new WebResourceResponse("text/plain", "utf-8", 404, "No encontrado", new HashMap<>(), new ByteArrayInputStream(new byte[0]));
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) { }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (archivoCallback != null) archivoCallback.onReceiveValue(null);
                archivoCallback = callback;
                return abrirSelector(params.getAcceptTypes());
            }
        });

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl("https://" + HOST + "/index.html");
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    private static String tipo(String ruta) {
        if (ruta.endsWith(".html")) return "text/html";
        if (ruta.endsWith(".js")) return "text/javascript";
        if (ruta.endsWith(".css")) return "text/css";
        if (ruta.endsWith(".png")) return "image/png";
        if (ruta.endsWith(".svg")) return "image/svg+xml";
        if (ruta.endsWith(".json")) return "application/json";
        return "application/octet-stream";
    }

    /** Selector de archivos: galería, documentos o la cámara para fotografiar un comprobante. */
    private boolean abrirSelector(String[] aceptados) {
        List<String> tipos = new ArrayList<>();
        boolean imagen = false;
        boolean comodin = false;
        if (aceptados != null) {
            for (String t : aceptados) {
                if (t == null) continue;
                for (String p : t.split(",")) {
                    p = p.trim();
                    if (p.isEmpty()) continue;
                    if (p.startsWith(".")) { comodin = true; continue; }
                    tipos.add(p);
                    if (p.startsWith("image/")) imagen = true;
                }
            }
        }

        Intent elegir = new Intent(Intent.ACTION_GET_CONTENT);
        elegir.addCategory(Intent.CATEGORY_OPENABLE);
        if (tipos.isEmpty() || comodin) {
            elegir.setType("*/*");
        } else if (tipos.size() == 1) {
            elegir.setType(tipos.get(0));
        } else {
            elegir.setType("*/*");
            elegir.putExtra(Intent.EXTRA_MIME_TYPES, tipos.toArray(new String[0]));
        }

        Intent selector = Intent.createChooser(elegir, "Elegir archivo");

        fotoUri = null;
        if (imagen && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Images.Media.DISPLAY_NAME, "comprobante_" + System.currentTimeMillis() + ".jpg");
                cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                cv.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/MisFinanzas");
                fotoUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
                if (fotoUri != null) {
                    Intent camara = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    camara.putExtra(MediaStore.EXTRA_OUTPUT, fotoUri);
                    camara.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    selector.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{camara});
                }
            } catch (Exception e) {
                fotoUri = null;
            }
        }

        try {
            startActivityForResult(selector, PEDIR_ARCHIVO);
            return true;
        } catch (Exception e) {
            if (archivoCallback != null) archivoCallback.onReceiveValue(null);
            archivoCallback = null;
            return false;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PEDIR_ARCHIVO) return;
        Uri[] resultado = null;
        if (resultCode == RESULT_OK) {
            if (data != null && data.getData() != null) {
                resultado = new Uri[]{data.getData()};
            } else if (data != null && data.getClipData() != null && data.getClipData().getItemCount() > 0) {
                resultado = new Uri[]{data.getClipData().getItemAt(0).getUri()};
            } else if (fotoUri != null) {
                resultado = new Uri[]{fotoUri};
            }
        }
        // Si no se usó la cámara, se borra la foto vacía que se había preparado
        if (fotoUri != null && (resultado == null || !fotoUri.equals(resultado[0]))) {
            try { getContentResolver().delete(fotoUri, null, null); } catch (Exception ignored) { }
        }
        if (archivoCallback != null) archivoCallback.onReceiveValue(resultado);
        archivoCallback = null;
        fotoUri = null;
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.onAndroidBack&&window.onAndroidBack())?'si':'no'", valor -> {
            if (valor == null || !valor.contains("si")) salir();
        });
    }

    private void salir() {
        super.onBackPressed();
    }

    private void aviso(String texto) {
        runOnUiThread(() -> Toast.makeText(this, texto, Toast.LENGTH_LONG).show());
    }

    /** Guarda un archivo en Descargas/MisFinanzas y devuelve su dirección. */
    private Uri guardarEnDescargas(String nombre, byte[] datos, String mime) throws IOException {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Downloads.DISPLAY_NAME, nombre);
            cv.put(MediaStore.Downloads.MIME_TYPE, mime);
            cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MisFinanzas");
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            if (uri == null) throw new IOException("sin acceso");
            try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out == null) throw new IOException("sin acceso");
                out.write(datos);
            }
            return uri;
        } else {
            File dir = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "MisFinanzas");
            if (!dir.exists() && !dir.mkdirs()) throw new IOException("sin acceso");
            File f = new File(dir, nombre);
            try (FileOutputStream out = new FileOutputStream(f)) {
                out.write(datos);
            }
            return Uri.fromFile(f);
        }
    }

    /** Funciones que la página puede llamar como Android.saveFile(...) */
    private class Puente {
        @JavascriptInterface
        public String saveFile(String nombre, String base64, String mime) {
            try {
                guardarEnDescargas(nombre, Base64.decode(base64, Base64.DEFAULT), mime);
                return "ok";
            } catch (Exception e) {
                aviso("No se pudo guardar el archivo");
                return "error";
            }
        }

        @JavascriptInterface
        public String openFile(String nombre, String base64, String mime) {
            try {
                Uri uri = guardarEnDescargas(nombre, Base64.decode(base64, Base64.DEFAULT), mime);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    Intent ver = new Intent(Intent.ACTION_VIEW);
                    ver.setDataAndType(uri, mime);
                    ver.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                    runOnUiThread(() -> {
                        try { startActivity(ver); } catch (Exception e) { aviso("Guardado en Descargas/MisFinanzas"); }
                    });
                } else {
                    aviso("Guardado en Descargas/MisFinanzas");
                }
                return "ok";
            } catch (Exception e) {
                aviso("No se pudo abrir el archivo");
                return "error";
            }
        }
    }
}
